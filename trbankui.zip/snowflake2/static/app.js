document.addEventListener('DOMContentLoaded', () => {
    // --- Application State ---
    const appState = {
        pdfFile: null,
        filename: '',
        camDocId: null,
        cvfDocId: null,
        camText: null,
        cvfText: null,
    };

    // --- Configuration (with defaults) ---
    let config = {
        sf_url: "https://DCSADOG-LS47860.snowflakecomputing.com",
        bearer: "",
        agent_db: "SNOWFLAKE_INTELLIGENCE",
        agent_schema: "AGENTS",
        cam_agent: "CAM",
        cvf_agent: "CVF",
        cam_validator: "CAM_VALIDATION",
        cvf_validator: "CVF_VALIDATION"
    };

    // --- DOM Element Selectors ---
    const elements = {
        navItems: document.querySelectorAll('.nav-item'),
        pages: document.querySelectorAll('.page'),
        loader: document.getElementById('loader'),
        loaderMessage: document.getElementById('loader-message'),
        logOutput: document.getElementById('log-output'),
        dropArea: document.getElementById('drop-area'),
        fileInput: document.getElementById('pdf_file'),
        fileNameDisplay: document.getElementById('file-name-display'),
        uploadBtn: document.getElementById('upload-btn'),
        processBtn: document.getElementById('process-btn'),
        extractBtn: document.getElementById('extract-btn'),
        renderImagesBtn: document.getElementById('render-images-btn'),
        validateBtn: document.getElementById('validate-btn'),
        saveConfigBtn: document.getElementById('save-config-btn'),
        camTextOutput: document.getElementById('cam-text-output'),
        cvfTextOutput: document.getElementById('cvf-text-output'),
        camAgentOutput: document.getElementById('cam-agent-output'),
        cvfAgentOutput: document.getElementById('cvf-agent-output'),
        camImagesOutput: document.getElementById('cam-images-output'),
        cvfImagesOutput: document.getElementById('cvf-images-output'),
        camValidationOutput: document.getElementById('cam-validation-output'),
        cvfValidationOutput: document.getElementById('cvf-validation-output'),
    };

    // --- UI Helper Functions ---
    const showLoader = (message) => { elements.loaderMessage.textContent = message; elements.loader.classList.remove('hidden'); };
    const hideLoader = () => elements.loader.classList.add('hidden');
    const log = (message, isError = false) => {
        const entry = document.createElement('div');
        entry.textContent = message;
        if (isError) entry.classList.add('error');
        elements.logOutput.prepend(entry);
    };
    const navigateToPage = (pageId) => {
        elements.pages.forEach(p => p.classList.remove('active'));
        document.getElementById(pageId).classList.add('active');
        elements.navItems.forEach(n => n.classList.remove('active'));
        document.querySelector(`.nav-item[data-page="${pageId}"]`).classList.add('active');
    };

    // --- Configuration Management ---
    const saveConfig = () => {
        Object.keys(config).forEach(key => {
            const inputId = `config-${key.replace(/_/g, '-')}`;
            config[key] = document.getElementById(inputId).value;
        });
        localStorage.setItem('creditAppConfig', JSON.stringify(config));
        log('Configuration saved.');
        if (!config.bearer) {
            log('Bearer token is empty! API calls will fail.', true);
        }
    };

    const loadConfig = () => {
        const savedConfig = localStorage.getItem('creditAppConfig');
        if (savedConfig) {
            config = JSON.parse(savedConfig);
        }
        Object.keys(config).forEach(key => {
            const inputId = `config-${key.replace(/_/g, '-')}`;
            const inputElement = document.getElementById(inputId);
            if (inputElement) {
                inputElement.value = config[key];
            }
        });
        if (!config.bearer) {
            log('Warning: Bearer token is not set. Please update it in the Configuration tab.', true);
        }
    };
    
    // --- API Call Handlers (Step-by-step logic) ---
    const handleUpload = async () => {
        if (!appState.pdfFile) { log('Please select a PDF file first.', true); return; }
        showLoader('Uploading and staging document...');
        const formData = new FormData();
        formData.append('pdf_file', appState.pdfFile);
        formData.append('cam_ranges', document.getElementById('cam_ranges').value);
        formData.append('cvf_ranges', document.getElementById('cvf_ranges').value);
        try {
            const response = await fetch('/upload', { method: 'POST', body: formData });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            appState.camDocId = data.cam_doc_id;
            appState.cvfDocId = data.cvf_doc_id;
            log('Upload successful.');
            if (appState.camDocId) log(`CAM ID: ${appState.camDocId}`);
            if (appState.cvfDocId) log(`CVF ID: ${appState.cvfDocId}`);
            elements.processBtn.disabled = false;
        } catch (error) { log(`Upload failed: ${error.message}`, true); } finally { hideLoader(); }
    };

    const handleProcess = async () => {
        showLoader('Parsing document and extracting text...');
        elements.processBtn.disabled = true;
        try {
            const response = await fetch('/process', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ cam_doc_id: appState.camDocId, cvf_doc_id: appState.cvfDocId, mode: document.getElementById('mode').value })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            appState.camText = data.cam_text;
            appState.cvfText = data.cvf_text;
            elements.camTextOutput.textContent = appState.camText || 'No CAM text extracted.';
            elements.cvfTextOutput.textContent = appState.cvfText || 'No CVF text extracted.';
            log('Text extraction successful.');
            elements.extractBtn.disabled = false;
            elements.renderImagesBtn.disabled = false;
        } catch (error) { log(`Processing failed: ${error.message}`, true); elements.processBtn.disabled = false; } finally { hideLoader(); }
    };

    const handleExtract = async () => {
        if (!config.bearer) { log('Bearer token is missing in configuration!', true); return; }
        showLoader('Running extraction agents...');
        elements.extractBtn.disabled = true;
        const payload = { ...config, filename: appState.filename, cam_doc_id: appState.camDocId, cvf_doc_id: appState.cvfDocId, cam_text: appState.camText, cvf_text: appState.cvfText };
        try {
            const response = await fetch('/extract', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            elements.camAgentOutput.textContent = JSON.stringify(data.results.CAM, null, 2) || 'No CAM agent result.';
            elements.cvfAgentOutput.textContent = JSON.stringify(data.results.CVF, null, 2) || 'No CVF agent result.';
            log('Agent extraction successful.');
            elements.validateBtn.disabled = false;
        } catch (error) { log(`Agent extraction failed: ${error.message}`, true); elements.extractBtn.disabled = false; } finally { hideLoader(); }
    };

    const handleRenderImages = async () => {
        if (!appState.pdfFile) { log('Original PDF file context lost. Please re-upload.', true); return; }
        showLoader('Rendering and uploading page images...');
        elements.renderImagesBtn.disabled = true;
        const formData = new FormData();
        formData.append('pdf_file', appState.pdfFile);
        formData.append('filename', appState.filename);
        formData.append('cam_ranges', document.getElementById('cam_ranges').value);
        formData.append('cvf_ranges', document.getElementById('cvf_ranges').value);
        try {
            const response = await fetch('/render-images', { method: 'POST', body: formData });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            elements.camImagesOutput.innerHTML = data.cam_image_paths.map(p => `<div>${p}</div>`).join('') || 'No CAM images generated.';
            elements.cvfImagesOutput.innerHTML = data.cvf_image_paths.map(p => `<div>${p}</div>`).join('') || 'No CVF images generated.';
            log('Image rendering successful.');
        } catch (error) { log(`Image rendering failed: ${error.message}`, true); } finally { hideLoader(); elements.renderImagesBtn.disabled = false; }
    };

    const handleValidate = async () => {
        if (!config.bearer) { log('Bearer token is missing in configuration!', true); return; }
        showLoader('Running validation agents...');
        elements.validateBtn.disabled = true;
        const payload = { ...config, cam_doc_id: appState.camDocId, cvf_doc_id: appState.cvfDocId };
        try {
            const response = await fetch('/validate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            elements.camValidationOutput.textContent = data.results.CAM_VALIDATION || 'No CAM validation result.';
            elements.cvfValidationOutput.textContent = data.results.CVF_VALIDATION || 'No CVF validation result.';
            log('Validation successful. Pipeline complete.');
        } catch(error) { log(`Validation failed: ${error.message}`, true); elements.validateBtn.disabled = false; } finally { hideLoader(); }
    };

    // --- Initial Setup and Event Listeners ---
    loadConfig();
    
    elements.navItems.forEach(item => item.addEventListener('click', () => navigateToPage(item.dataset.page)));
    elements.saveConfigBtn.addEventListener('click', saveConfig);
    elements.uploadBtn.addEventListener('click', handleUpload);
    elements.processBtn.addEventListener('click', handleProcess);
    elements.extractBtn.addEventListener('click', handleExtract);
    elements.renderImagesBtn.addEventListener('click', handleRenderImages);
    elements.validateBtn.addEventListener('click', handleValidate);

    const handleFileSelect = (file) => {
        if (file && file.type === 'application/pdf') {
            appState.pdfFile = file;
            appState.filename = file.name;
            elements.fileNameDisplay.textContent = appState.filename;
            log(`File selected: ${appState.filename}`);
        } else { log('Please select a valid PDF file.', true); }
    };
    elements.dropArea.addEventListener('dragover', (e) => e.preventDefault());
    elements.dropArea.addEventListener('drop', (e) => { e.preventDefault(); handleFileSelect(e.dataTransfer.files[0]); });
    elements.dropArea.addEventListener('click', () => elements.fileInput.click());
    elements.fileInput.addEventListener('change', () => handleFileSelect(elements.fileInput.files[0]));
});
