# main.py
# Flask backend for Credit File processing.
# It exposes API endpoints that the HTML/JS frontend will call.

import os
import io
import re
import json
import time
import random
from pathlib import Path
from uuid import uuid4
from concurrent.futures import ThreadPoolExecutor, as_completed

# pip install Flask snowflake-connector-python requests pypdf PyMuPDF
from flask import Flask, request, jsonify, render_template

import snowflake.connector
import requests

# Prefer PyMuPDF for images; fallback to pypdf for splitting only
try:
    import fitz  # PyMuPDF
    _HAVE_PYMUPDF = True
except Exception:
    fitz = None
    _HAVE_PYMUPDF = False

try:
    from pypdf import PdfReader, PdfWriter
    _HAVE_PYPDF = True
except Exception:
    PdfReader = PdfWriter = None
    _HAVE_PYPDF = False


# =========================
# ---- CONFIG (EDIT ME) ----
# =========================
ACCOUNT   = "DCSADOG-LS47860"      # no https / no domain
USER      = "HARI"
PASSWORD  = "H@ri9444708755"   # you can use PAT here
ROLE      = "ACCOUNTADMIN"
WAREHOUSE = "DOC_PROCESSING_WH"
DATABASE  = "DOC_PROCESSING_DB"
SCHEMA    = "DOC_AI_SCHEMA"

AGENT_DB     = os.getenv("SF_AGENT_DB",     "SNOWFLAKE_INTELLIGENCE")
AGENT_SCHEMA = os.getenv("SF_AGENT_SCHEMA", "AGENTS")

STAGE_FQN       = f'"{DATABASE}"."{SCHEMA}"."DOC_INPUT"'
PROC_CREDIT_FQN = f'"{DATABASE}"."{SCHEMA}"."PROCESS_CREDIT_DOC"'

STAGE_PREFIX_CAM       = "credit_uploads/CAM"
STAGE_PREFIX_CVF       = "credit_uploads/CVF"
STAGE_PREFIX_CAM_IMG   = "credit_images/CAM"
STAGE_PREFIX_CVF_IMG   = "credit_images/CVF"

MAX_TEXT_CHARS = 12000

# =========================
# ---- FLASK APP SETUP ----
# =========================
app = Flask(__name__)


# =========================
# ---- SNOWFLAKE & HELPERS ---- (Copied directly from your script)
# =========================
def get_sql_conn():
    # In a real production app, use a connection pool.
    # For this demo, a new connection per request is simple and safe.
    return snowflake.connector.connect(
        account=ACCOUNT, user=USER, password=PASSWORD, role=ROLE,
        warehouse=WAREHOUSE, database=DATABASE, schema=SCHEMA,
        autocommit=True,
    )

# ... (All your helper functions: _sanitize_name, parse_page_ranges, etc. go here) ...
# ... (I've included them below for completeness) ...
def _sanitize_name(s: str, max_len: int = 120) -> str:
    s = Path(s).stem
    s = re.sub(r"\s+", "_", s)
    s = re.sub(r"[^A-Za-z0-9_\-]+", "", s)
    return s[:max_len]

def parse_page_ranges(s: str):
    pages = set()
    if not s: return []
    for part in s.replace(" ", "").split(","):
        if not part: continue
        if "-" in part:
            a, b = part.split("-", 1)
            try: start, end = int(a), int(b)
            except ValueError: continue
            if start > end: start, end = end, start
            pages.update(range(start, end + 1))
        else:
            try: pages.add(int(part))
            except ValueError: pass
    return sorted(p for p in pages if p >= 1)

def extract_pages_to_bytes_from_bytes(pdf_bytes: bytes, pages_1based):
    if not pages_1based: raise ValueError("No pages specified")
    if _HAVE_PYMUPDF:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        newdoc = fitz.open()
        max_page = doc.page_count
        for p1 in pages_1based:
            if 1 <= p1 <= max_page: newdoc.insert_pdf(doc, from_page=p1 - 1, to_page=p1 - 1)
        return io.BytesIO(newdoc.tobytes())
    if _HAVE_PYPDF:
        reader = PdfReader(io.BytesIO(pdf_bytes))
        writer = PdfWriter()
        max_page = len(reader.pages)
        for p1 in pages_1based:
            if 1 <= p1 <= max_page: writer.add_page(reader.pages[p1 - 1])
        out = io.BytesIO()
        writer.write(out)
        out.seek(0)
        return out
    raise RuntimeError("Install PyMuPDF or pypdf")

def render_pages_to_images(pdf_bytes: bytes, pages_1based, dpi: int = 180):
    if not _HAVE_PYMUPDF: raise RuntimeError("Page→image requires PyMuPDF. `pip install PyMuPDF`")
    out = []
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    max_page = doc.page_count
    zoom = dpi / 72.0
    mat = fitz.Matrix(zoom, zoom)
    for p1 in pages_1based:
        if 1 <= p1 <= max_page:
            pix = doc.load_page(p1 - 1).get_pixmap(matrix=mat, alpha=False)
            out.append((p1, pix.tobytes("png")))
    return out

def put_stream_to_stage(cur, bytes_io: io.BytesIO, staged_filename: str, subdir: str):
    bytes_io.seek(0)
    local_uri = f"file://ignored/{staged_filename}".replace("'", "''")
    stage_dir = f'@{STAGE_FQN}/{subdir}'
    cur.execute(f"PUT '{local_uri}' {stage_dir} AUTO_COMPRESS=FALSE OVERWRITE=TRUE", file_stream=bytes_io)

def put_bytes_to_stage(cur, raw_bytes: bytes, staged_filename: str, subdir: str):
    put_stream_to_stage(cur, io.BytesIO(raw_bytes), staged_filename, subdir)

def insert_credit_metadata(cur, credit_doc_id: str, section_type: str, filename: str, size_bytes: int, mime: str, page_ranges: str, stage_rel_path: str):
    cur.execute("""
        INSERT INTO CREDIT_DOCUMENT_METADATA
          (CREDIT_DOC_ID, ORIGINAL_DOCUMENT_ID, SECTION_TYPE, SOURCE_PAGE_RANGES, ORIGINAL_FILENAME, FILE_SIZE_BYTES, FILE_TYPE, STAGE_PATH, PROCESSING_STATUS)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'UPLOADED')
        """, (credit_doc_id, None, section_type, page_ranges, filename, size_bytes, mime, stage_rel_path))

def call_credit_proc(cur, credit_doc_id: str, mode: str) -> str:
    cur.execute(f"CALL {PROC_CREDIT_FQN}(%s, %s)", (credit_doc_id, mode))
    return cur.fetchone()[0]

def fetch_latest_credit_extraction(cur, credit_doc_id: str):
    cur.execute("""
        SELECT m.ORIGINAL_FILENAME AS DOCUMENT_NAME, e.EXTRACTED_CONTENT
        FROM CREDIT_DOCUMENT_METADATA m
        JOIN CREDIT_EXTRACTED_TEXT e ON e.CREDIT_DOC_ID = m.CREDIT_DOC_ID
        WHERE m.CREDIT_DOC_ID = %s ORDER BY e.EXTRACTION_TIMESTAMP DESC LIMIT 1
        """, (credit_doc_id,))
    row = cur.fetchone()
    return (row[0], row[1]) if row else (None, None)

def make_extract_prompt(filename: str, doc_id: str, section: str, content: str) -> str:
    text = content or ""
    if len(text) > MAX_TEXT_CHARS: text = text[:MAX_TEXT_CHARS] + "\n\n[...TRUNCATED...]"
    return (f"FILENAME: {filename}\nSECTION: {section}\nCREDIT_DOC_ID: {doc_id}\n\n"
            f"EXTRACTED_TEXT:\n{text}\n")

def run_agent_once(base_url: str, db: str, schema: str, agent: str, bearer: str, prompt: str, timeout=300):
    url = f"{base_url}/api/v2/databases/{db}/schemas/{schema}/agents/{agent}:run"
    headers = {"Authorization": f"Bearer {bearer}", "Accept": "text/event-stream", "Content-Type": "application/json"}
    body = {"messages": [{"role": "user", "content": [{"type": "text", "text": prompt}]}]}
    out = []
    with requests.post(url, headers=headers, json=body, stream=True, timeout=timeout) as r:
        r.raise_for_status()
        event = None
        for line in r.iter_lines(decode_unicode=True):
            if not line: continue
            if line.startswith("event:"): event = line.split("event:", 1)[1].strip()
            elif line.startswith("data:"):
                data_str = line.split("data:", 1)[1].strip()
                try: payload = json.loads(data_str)
                except Exception: continue
                if event == "response.text.delta":
                    tok = payload.get("text", "")
                    if tok: out.append(tok)
                elif event == "response.completed": break
    return "".join(out).strip()

def run_agent_sql_with_retry(base_url: str, db: str, schema: str, agent: str, bearer: str, sql_text: str, attempts: int = 3, timeout: int = 300) -> str:
    last_err = None
    for i in range(1, attempts + 1):
        try: return run_agent_once(base_url, db, schema, agent, bearer, sql_text, timeout=timeout)
        except Exception as e:
            last_err = e
            if i == attempts: break
            time.sleep(0.5 * (2 ** (i - 1)) + random.uniform(0, 0.3))
    raise last_err

# =========================
# ---- API ENDPOINTS ----
# =========================
@app.route("/")
def index():
    """Serve the main HTML page."""
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload_and_split():
    """Step 1: Upload PDF, split, and stage CAM/CVF subsets."""
    try:
        if 'pdf_file' not in request.files:
            return jsonify({"error": "No file part"}), 400
        
        file = request.files['pdf_file']
        cam_ranges_str = request.form.get("cam_ranges", "")
        cvf_ranges_str = request.form.get("cvf_ranges", "")

        if not cam_ranges_str and not cvf_ranges_str:
            return jsonify({"error": "Please specify at least one of CAM or CVF page ranges."}), 400

        cam_pages = parse_page_ranges(cam_ranges_str)
        cvf_pages = parse_page_ranges(cvf_ranges_str)
        
        pdf_bytes = file.read()
        base_name = _sanitize_name(file.filename)
        mime = file.content_type or "application/pdf"
        
        conn = get_sql_conn()
        cur = conn.cursor()
        
        cam_doc_id, cvf_doc_id = None, None
        
        if cam_pages:
            cam_pdf = extract_pages_to_bytes_from_bytes(pdf_bytes, cam_pages)
            cam_file = f"{base_name}__CAM.pdf"
            put_stream_to_stage(cur, cam_pdf, cam_file, STAGE_PREFIX_CAM)
            cam_doc_id = uuid4().hex
            insert_credit_metadata(cur, cam_doc_id, "CAM", file.filename, cam_pdf.getbuffer().nbytes, mime, cam_ranges_str, f"{STAGE_PREFIX_CAM}/{cam_file}")
            
        if cvf_pages:
            cvf_pdf = extract_pages_to_bytes_from_bytes(pdf_bytes, cvf_pages)
            cvf_file = f"{base_name}__CVF.pdf"
            put_stream_to_stage(cur, cvf_pdf, cvf_file, STAGE_PREFIX_CVF)
            cvf_doc_id = uuid4().hex
            insert_credit_metadata(cur, cvf_doc_id, "CVF", file.filename, cvf_pdf.getbuffer().nbytes, mime, cvf_ranges_str, f"{STAGE_PREFIX_CVF}/{cvf_file}")

        cur.close()
        conn.close()
        
        return jsonify({
            "success": True,
            "message": "Subsets uploaded successfully.",
            "cam_doc_id": cam_doc_id,
            "cvf_doc_id": cvf_doc_id
        })

    except Exception as e:
        return jsonify({"error": f"Upload/split failed: {str(e)}"}), 500


@app.route("/process", methods=["POST"])
def process_documents():
    """Step 2: Run the parsing stored procedure and fetch extracted text."""
    try:
        data = request.json
        cam_doc_id = data.get("cam_doc_id")
        cvf_doc_id = data.get("cvf_doc_id")
        mode = data.get("mode", "LAYOUT")
        
        conn = get_sql_conn()
        cur = conn.cursor()
        
        cam_text, cvf_text = None, None
        
        if cam_doc_id:
            call_credit_proc(cur, cam_doc_id, mode)
            _, cam_text = fetch_latest_credit_extraction(cur, cam_doc_id)
        
        if cvf_doc_id:
            call_credit_proc(cur, cvf_doc_id, mode)
            _, cvf_text = fetch_latest_credit_extraction(cur, cvf_doc_id)
            
        cur.close()
        conn.close()
        
        return jsonify({
            "success": True,
            "cam_text": cam_text,
            "cvf_text": cvf_text
        })
        
    except Exception as e:
        return jsonify({"error": f"Processing failed: {str(e)}"}), 500


@app.route("/extract", methods=["POST"])
def extract_with_agents():
    """Step 3: Call Cortex extraction agents in parallel."""
    try:
        data = request.json
        results = {}
        with ThreadPoolExecutor(max_workers=2) as ex:
            futs = {}
            if data.get("cam_text"):
                prompt = make_extract_prompt(data.get("filename"), data["cam_doc_id"], "CAM", data["cam_text"])
                futs[ex.submit(run_agent_once, data["sf_url"], data["agent_db"], data["agent_schema"], data["cam_agent"], data["bearer"], prompt)] = "CAM"
            
            if data.get("cvf_text"):
                prompt = make_extract_prompt(data.get("filename"), data["cvf_doc_id"], "CVF", data["cvf_text"])
                futs[ex.submit(run_agent_once, data["sf_url"], data["agent_db"], data["agent_schema"], data["cvf_agent"], data["bearer"], prompt)] = "CVF"

            for fut in as_completed(futs):
                k = futs[fut]
                try: results[k] = fut.result()
                except Exception as e: results[k] = f"ERROR: {e}"
        
        return jsonify({"success": True, "results": results})
        
    except Exception as e:
        return jsonify({"error": f"Agent extraction failed: {str(e)}"}), 500


@app.route("/render-images", methods=["POST"])
def render_and_upload_images():
    """Step 4: Render page images and upload them to a stage."""
    try:
        if 'pdf_file' not in request.files:
            return jsonify({"error": "Original PDF file is required"}), 400

        pdf_bytes = request.files['pdf_file'].read()
        cam_pages = parse_page_ranges(request.form.get("cam_ranges", ""))
        cvf_pages = parse_page_ranges(request.form.get("cvf_ranges", ""))
        filename = request.form.get("filename", "document")
        base_name = _sanitize_name(filename)

        conn = get_sql_conn()
        cur = conn.cursor()

        cam_img_paths, cvf_img_paths = [], []
        if cam_pages:
            for pnum, png in render_pages_to_images(pdf_bytes, cam_pages):
                fname = f"{base_name}__CAM_p{pnum}.png"
                put_bytes_to_stage(cur, png, fname, STAGE_PREFIX_CAM_IMG)
                cam_img_paths.append(f"{STAGE_PREFIX_CAM_IMG}/{fname}")

        if cvf_pages:
            for pnum, png in render_pages_to_images(pdf_bytes, cvf_pages):
                fname = f"{base_name}__CVF_p{pnum}.png"
                put_bytes_to_stage(cur, png, fname, STAGE_PREFIX_CVF_IMG)
                cvf_img_paths.append(f"{STAGE_PREFIX_CVF_IMG}/{fname}")

        cur.close()
        conn.close()

        return jsonify({"success": True, "cam_image_paths": cam_img_paths, "cvf_image_paths": cvf_img_paths})
    except Exception as e:
        return jsonify({"error": f"Image rendering failed: {str(e)}"}), 500


@app.route("/validate", methods=["POST"])
def validate_with_agents():
    """Step 5: Call Cortex validation agents in parallel."""
    try:
        data = request.json
        val_results = {}

        def build_sql(doc_id: str, section: str):
            return f"CALL {DATABASE}.{SCHEMA}.VALIDATE_SECTION('{doc_id}', '{section}', 5);"

        with ThreadPoolExecutor(max_workers=2) as ex:
            futs = {}
            if data.get("cam_doc_id"):
                sql = build_sql(data["cam_doc_id"], "CAM")
                futs[ex.submit(run_agent_sql_with_retry, data["sf_url"], data["agent_db"], data["agent_schema"], data["cam_validator"], data["bearer"], sql)] = "CAM_VALIDATION"
            
            if data.get("cvf_doc_id"):
                sql = build_sql(data["cvf_doc_id"], "CVF")
                futs[ex.submit(run_agent_sql_with_retry, data["sf_url"], data["agent_db"], data["agent_schema"], data["cvf_validator"], data["bearer"], sql)] = "CVF_VALIDATION"

            for fut in as_completed(futs):
                key = futs[fut]
                try: val_results[key] = fut.result()
                except Exception as e: val_results[key] = f"ERROR: {type(e).__name__}: {e}"

        return jsonify({"success": True, "results": val_results})
    except Exception as e:
        return jsonify({"error": f"Validation flow failed: {str(e)}"}), 500


if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=8080)
